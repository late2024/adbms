install.packages("arules")
library(arules)
#' @importClassesFrom arules transactions
transactions <- list(
  c("Onion","Carrot","Raddish"),
  c("Onion","Potato"),
  c("Carrot","Potato"),
  c("Onion","Carrot","Potato"),
  c("Onion","Carrot")
)
trans <- as(transactions, "transactions")
rules <- apriori(trans, parameter = list(supp = 0.2, conf = 0.8))
inspect(rules)