x = 5.6
print(class(x))
print(typeof(x))
print (x)

y = 5
print(class(y))
print(typeof(y))
