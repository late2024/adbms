x = as.integer(5)
print(class(x))
print(typeof(x))
y = 5L
print(class(y))
print(typeof(y))
