# Assign a complex value to variable x
x = 5 + 3i
# print the class name of variable x
print(class(x))
# print the type of variable x
print(typeof(x))