# Assign a character value to char
char = "Bhushan"
# print the class name of char
print(class(char))
# print the type of char
print(typeof(char))
