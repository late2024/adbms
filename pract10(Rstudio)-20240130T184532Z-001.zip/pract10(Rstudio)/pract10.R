install.packages("ggplot2")
install.packages("cluster")
library(ggplot2)
library(cluster)
set.seed(123)
data <- data.frame(
  x = rnorm(100, mean = 0),
  y = rnorm(100, mean = 0)
)
kmeans_result <- kmeans(data, centers = 3)
data$cluster <- as.factor(kmeans_result$cluster)
ggplot(data, aes(x, y, color = cluster)) +
  geom_point() +
  geom_point(data = as.data.frame(kmeans_result$centers), aes(x, y), color = "black", size = 4, shape = 4)