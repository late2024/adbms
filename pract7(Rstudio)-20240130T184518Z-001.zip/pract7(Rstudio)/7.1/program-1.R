install.packages("xlsx")
library(xlsx)
ageheight <- read.xlsx("C:\\Users\\ADMIN\\Desktop\\mca_09\\adbms\\pract7.xlsx",sheetName = "SHEET1")
result <- lm(height~age,data=ageheight)
summary(result)

