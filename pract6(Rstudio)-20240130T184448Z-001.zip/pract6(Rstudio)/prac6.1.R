dataframe <- read.csv("prac6.csv")
print(dataframe)
names(dataframe)[names(dataframe) == "Name"] <- "FirstName"
print(dataframe)
dataframe$emailaddress <- c('bhushan@gmail.com', 'atharva@gmail.com', 'kunal@gmail.com',
                            'sidd@gmail.com', 'pari@gmail.com','shivam@gmail.com')
print(dataframe)
dataframe <- dataframe[complete.cases(dataframe), ]
print(dataframe)
dataframe <- read.csv("prac6.csv")
dataframe$Age <- ifelse(
  is.na(dataframe$Age), 
  ave(dataframe$Age, FUN = function(x) mean(x, na.rm = TRUE)), 
  dataframe$Age 
)
print(dataframe)

dataframe$Salary <- ifelse(
  is.na(dataframe$Salary),
  ave(dataframe$Salary, FUN = function(x) mean(x, na.rm = TRUE)), 
  dataframe$Salary 
)
print(dataframe)

dataframe$Gender <- as.numeric(factor(dataframe$Gender))
print(dataframe)
subset_data <- dataframe[dataframe$Age > 19, ]
print(subset_data)
dataframe <- read.csv("prac6.csv")
print(dataframe)

sample_size <- 3 
sample_data <- dataframe[sample(nrow(dataframe), sample_size, replace = FALSE), ]
print(sample_data)
